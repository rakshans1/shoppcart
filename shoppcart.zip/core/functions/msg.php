
<?php
$message ='<<<EOF

	<html>
	<body>
	<table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color:#f7f7f7">
		<tbody>
			<tr>
				<td width="580" align="center" style="padding-top:20px ">
				<table height="40" width="580" align="center" border="0" cellpadding="0" cellspacing="0" style="background-color:#ffffff">
				<tbody><tr>
						<td width="580" align="left" style="padding:30px 30px 20px 30px">
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tbody><tr>
				<td align="left" valign="bottom" height="50">
				<a href="shoppcart.dev" title="Visit Shoppcart" target="_blank">
						<img width="139" height="39" border="0" src="https://googledrive.com/host/0B5FKToPv769iOUR5ZjZwWWxqR1U" style="text-decoration:none;display:block;outline:none" class="CToWUd">
						</a>
						</td>
						</tr>
						</tbody></table>
						</td>
						</tr>
						</tbody></table>
						</td>
						</tr>
						</tbody>
	</table>



<table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color:#f7f7f7">
				<tbody><tr>
				<td width="580" align="center"  >
				<table width="580" align="center" border="0" cellpadding="0" cellspacing="0" style="background-color:#ffffff">
				<tbody><tr>
				<td align="center" style="padding:0 30px 50px 30px">
				<table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse">
				<tbody><tr>
				<td align="left" valign="bottom" style="padding:0 0 35px 0">
				<table width="400">
				<tbody><tr>
				<td style="padding:0 0 0 0;font-family:helvetica neue,helvetica,arial,sans-serif;font-weight:bold;font-size:32px;line-height:36px;color:#444444;max-width:510px;overflow:hidden;text-overflow:ellipsis">
				Hello  Before we <span style="color:#FE980F">get started</span>
				</td>
				</tr>
				</tbody></table>
				</td>
				</tr>
				</tbody></table>
				<table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse">
				<tbody><tr>
				<td align="left" valign="bottom" style="padding:0 0 40px 0;font-family:helvetica neue,helvetica,arial,sans-serif;font-size:22px;line-height:26px;color:#444444">
				Please take a second to make sure we have got your Email right.
				</td>
				</tr>
				</tbody></table>
				<table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse">
				<tbody><tr>
				<td align="center" style="padding:0 35px 0 35px">
				<a href="    " style="text-decoration:none;display:block" target="_blank">
				<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tbody><tr>
				<td align="center" style="padding:14px 20px 14px 20px;background-color:#FE980F;border-radius:4px">
				<a href=" "    " style="font-family:helvetica neue,helvetica,arial,sans-serif;font-weight:bold;font-size:18px;line-height:22px;color:#ffffff;text-decoration:none;display:block;text-align:center;max-width:400px;overflow:hidden;text-overflow:ellipsis" target="_blank">
				Confirm your email
				</a>
				</td>
				</tr>
				</tbody></table>
				</a>
				</td>
				</tr>
				</tbody></table>
				</td>
				</tr>
				</tbody></table>
				</td>
			</tr>
			</tbody>
</table>

<table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color:#f7f7f7">
				<tbody><tr>
				<td width="580" align="center"  > .</td></tr></tbody></table>
				</body>
				</html>



EOF';

?>
